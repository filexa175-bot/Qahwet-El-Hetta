قهوة الحتة — مستودع بناء APK تجريبي عبر GitHub Actions

محتويات المستودع:
- .github/workflows/build-android-apk.yml: سير العمل الذي يبني APK في السحابة.
- source/qahwa_android_source.zip: ملفات تطبيق Android ومحتوى اللعبة.

طريقة الرفع:
ارفع محتويات هذا المجلد إلى جذر مستودع GitHub، مع الحفاظ على أسماء المجلدات والمسارات كما هي.
ثم افتح Actions واختر Build Qahwet El Hetta APK ثم Run workflow.

ملاحظة: الناتج APK تجريبي Debug للتثبيت والاختبار، وليس إصدارًا موقعًا للنشر على Google Play.
